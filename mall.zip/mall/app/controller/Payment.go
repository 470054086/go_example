package controller

type Payment struct {

}

func (p *Payment) Index()  {

}