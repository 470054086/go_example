package service

import "fmt"

type Payment struct {
	
}

func init()  {
	fmt.Println(2222)
}
